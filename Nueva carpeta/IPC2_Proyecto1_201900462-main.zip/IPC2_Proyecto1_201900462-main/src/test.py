from models import Matriz

matrix = Matriz('nombre', 3, 3)
matrix.print_matrix()
