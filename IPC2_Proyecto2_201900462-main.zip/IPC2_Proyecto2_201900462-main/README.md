# IPC2_Proyecto2_201900462

Repositorio del proyecto 2 del curso de IPC2 1er Semestre 2021

**Nombre**: Xhunik Nikol Miguel Mutzutz

**Carnet**: 201900462
