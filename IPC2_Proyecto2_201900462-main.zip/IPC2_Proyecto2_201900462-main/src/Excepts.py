class MatrixSizeException(Exception):
    pass

class InvalidRangeException(Exception):
    pass